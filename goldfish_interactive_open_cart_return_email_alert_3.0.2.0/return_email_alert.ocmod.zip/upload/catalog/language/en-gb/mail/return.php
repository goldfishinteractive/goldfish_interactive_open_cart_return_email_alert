<?php
// Text
$_['text_subject']          = '%s - New Return Request Captured %s';
$_['text_return_id']        = 'Return ID:';
$_['text_order_id']         = 'Order ID:';
$_['text_firstname']        = 'First Name:';
$_['text_lastname']         = 'Last Name:';
$_['text_email']            = 'Email:';
$_['text_telephone']        = 'Telephone:';
$_['text_product']          = 'Product:';
$_['text_model']            = 'Model:';
$_['text_quantity']         = 'Quantity:';
$_['text_opened']           = 'Opened:';
$_['text_reason']           = 'Reason:';
$_['text_action']           = 'Action:';
$_['text_status']           = 'Status:';
$_['text_comment']          = 'Comments:';
$_['text_date_ordered']     = 'Date Ordered:';
$_['text_date_added']       = 'Return Date:';
$_['text_date_modified']    = 'Date Modified:';